"""
Author:
    Jie Xu. 2020.1.1. in the UESTC
"""
from Load_data import load_data_conv
from tensorflow.keras.optimizers import Adam
import numpy as np
import os
from time import time
import Nmetrics
from MVDEC import MvDEC
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings("ignore")


def _make_data_and_model(args, view=2):
    # prepare dataset
    if view == 2:
        x1, x2, y = load_data_conv(args.dataset)
    else:
        x1, x2, x3, y = load_data_conv(args.dataset)
    # prepare optimizer
    optimizer = Adam(lr=args.lr)

    # prepare the model
    n_clusters = len(np.unique(y))
    print('cluster:' + str(n_clusters))
    if view == 2:
        model = MvDEC(input1_shape=x1.shape[1:], input2_shape=x2.shape[1:], filters=[32, 64, 128, n_clusters], view=view)

        model.compile(optimizer=optimizer, loss=['kld', 'mse', 'kld', 'mse'],
                      loss_weights=[0.1, args.Idec, 0.1, args.Idec])
        return (x1, x2, y), model
    if view == 3:
        model = MvDEC(input1_shape=x1.shape[1:], input2_shape=x2.shape[1:], filters=[32, 64, 128, n_clusters], view=view,
                      input3_shape=x3.shape[1:])

        model.compile(optimizer=optimizer, loss=['kld', 'mse', 'kld', 'mse', 'kld', 'mse'],
                      loss_weights=[0.1, args.Idec, 0.1, args.Idec, 0.1, args.Idec])
        return (x1, x2, x3, y), model
        #  α、β [0.1, 1.0, 0.1, 1.0]


def train(args, view=2):
    # get data and mode
    if view == 2:
        (x1, x2, y), model = _make_data_and_model(args, view)
    else:
        (x1, x2, x3, y), model = _make_data_and_model(args, view)
    model.model.summary()

    # pretraining
    t0 = time()
    if not os.path.exists(args.save_dir):
        os.makedirs(args.save_dir)
    if args.pretrain_dir is not None and os.path.exists(args.pretrain_dir):  # load pretrained weights
        model.autoencoder.load_weights(args.pretrain_dir)
    else:  # train
        optimizer = Adam(lr=args.lr)
        if view == 2:
            model.pretrain2(x1, x2, y, y, optimizer=optimizer, epochs=args.pretrain_epochs, batch_size=args.batch_size,
                            save_dir=args.save_dir, verbose=args.verbose)
        if view == 3:
            model.pretrain3(x1, x2, x3, y, y, y, optimizer=optimizer, epochs=args.pretrain_epochs,
                            batch_size=args.batch_size, save_dir=args.save_dir, verbose=args.verbose)

    t1 = time()
    print("Time for pretraining: %ds" % (t1 - t0))

    # clustering
    if view == 2:
        y_pred1, y_pred2, y_pred = model.fit2(arg=args, x1=x1, x2=x2, y=y, maxiter=args.maxiter,
                                     batch_size=args.batch_size, UpdateCoo=args.UpdateCoo,
                                     save_dir=args.save_dir)
        if y is not None:
            print('Final: acc=%.4f, nmi=%.4f, ari=%.4f' %
                  (Nmetrics.acc(y, y_pred1), Nmetrics.nmi(y, y_pred1), Nmetrics.ari(y, y_pred1)))
            print('Final: acc=%.4f, nmi=%.4f, ari=%.4f' %
                  (Nmetrics.acc(y, y_pred2), Nmetrics.nmi(y, y_pred2), Nmetrics.ari(y, y_pred2)))
            print('Final: acc=%.4f, nmi=%.4f, ari=%.4f' %
                  (Nmetrics.acc(y, y_pred), Nmetrics.nmi(y, y_pred), Nmetrics.ari(y, y_pred)))
    if view == 3:
        y_pred1, y_pred2, y_pred3, y_pred = model.fit3(arg=args, x1=x1, x2=x2, x3=x3, y=y, maxiter=args.maxiter,
                                               batch_size=args.batch_size, UpdateCoo=args.UpdateCoo,
                                               save_dir=args.save_dir)
        if y is not None:
            print('Final: acc=%.4f, nmi=%.4f, ari=%.4f' %
                  (Nmetrics.acc(y, y_pred1), Nmetrics.nmi(y, y_pred1), Nmetrics.ari(y, y_pred1)))
            print('Final: acc=%.4f, nmi=%.4f, ari=%.4f' %
                  (Nmetrics.acc(y, y_pred2), Nmetrics.nmi(y, y_pred2), Nmetrics.ari(y, y_pred2)))
            print('Final: acc=%.4f, nmi=%.4f, ari=%.4f' %
                  (Nmetrics.acc(y, y_pred3), Nmetrics.nmi(y, y_pred3), Nmetrics.ari(y, y_pred3)))
            print('Final: acc=%.4f, nmi=%.4f, ari=%.4f' %
                  (Nmetrics.acc(y, y_pred), Nmetrics.nmi(y, y_pred), Nmetrics.ari(y, y_pred)))
    t2 = time()
    print("Time for pretaining, clustering and total: (%ds, %ds, %ds)" % (t1 - t0, t2 - t1, t2 - t0))
    print('='*60)


def test(args, view=2):
    # assert args.weights is not None
    if view == 2:
        (x1, x2, y), model = _make_data_and_model(args, view)
        model.model.summary()
        print('Begin testing:', '-' * 60)
        model.load_weights(args.weights)
        [y_pred1, y_pred2, q1, q2] = model.predict_labels2(x1, x2)
        [features1, features2] = model.encoder.predict({'input1': x1, 'input2': x2})
        [out1, out2] = model.autoencoder.predict({'input1': x1, 'input2': x2})

        xx1 = np.reshape(x1, np.shape(x1)[0:3])
        xx2 = np.reshape(x2, np.shape(x2)[0:3])
        out1 = np.reshape(out1, np.shape(out1)[0:3])
        out2 = np.reshape(out2, np.shape(out2)[0:3])
        print(out1.shape)
        print(xx2.shape)
        lag1 = y_pred1
        lag2 = y_pred2
        bothview = np.absolute(lag1 - lag2)
        index_tmp = np.where(bothview == 0)
        index = np.array(index_tmp)[0]
        index = index[1:20]

        print("Show 20 samples:")
        for i in range(len(index)):
            ge = [index[i]]
            image1 = xx1[ge[0]]
            image2 = out1[ge[0]]
            image3 = xx2[ge][0]
            image4 = out2[ge][0]
            plt.figure(str(y[ge[0]]) + ' ' + str(y_pred1[ge[0]]) + ' ' + str(y_pred2[ge[0]]) + '   No.' + str(ge[0]))
            mngr = plt.get_current_fig_manager()
            mngr.window.wm_geometry("+0+0")  # Adjust the window to pop up on the screen
            plt.gca().xaxis.set_major_locator(plt.NullLocator())
            plt.gca().yaxis.set_major_locator(plt.NullLocator())
            plt.subplots_adjust(top=1, bottom=0, right=1, left=0, hspace=0, wspace=0)
            plt.margins(0, 0)
            plt.subplot(2, 2, 1)
            plt.title(str(y[ge[0]]))
            plt.imshow(image1)
            plt.subplot(2, 2, 2)
            plt.title(str(y_pred1[ge[0]]))
            plt.imshow(image2)
            plt.subplot(2, 2, 3)
            plt.title(str(y[ge[0]]))
            plt.imshow(image3)
            plt.subplot(2, 2, 4)
            plt.title(str(y_pred2[ge[0]]))
            plt.imshow(image4)
            plt.show()

        # c1, c2 = model.get_layers2()
        q_pred = (q1 + q2)/2
        y_pred = np.argmax(q_pred, 1)
        print('V1:\t acc=%.4f, nmi=%.4f, v-measure=%.4f, ari=%.4f' % (Nmetrics.acc(y, y_pred1), Nmetrics.nmi(y, y_pred1),
                                                                Nmetrics.vmeasure(y, y_pred1), Nmetrics.ari(y, y_pred1)))
        print('V2:\t acc=%.4f, nmi=%.4f, v-measure=%.4f, ari=%.4f' % (Nmetrics.acc(y, y_pred2), Nmetrics.nmi(y, y_pred2),
                                                                Nmetrics.vmeasure(y, y_pred2), Nmetrics.ari(y, y_pred2)))
        print('DEMCCT:\t acc=%.4f, nmi=%.4f, v-measure=%.4f, ari=%.4f' % (Nmetrics.acc(y, y_pred), Nmetrics.nmi(y, y_pred),
                                                                Nmetrics.vmeasure(y, y_pred), Nmetrics.ari(y, y_pred)))
        print('End testing:', '-' * 60)

    if view == 3:
        (x1, x2, x3, y), model = _make_data_and_model(args, view)
        model.model.summary()
        print('Begin testing:', '-' * 60)
        model.load_weights(args.weights)
        [y_pred1, y_pred2, y_pred3, q1, q2, q3] = model.predict_labels3(x1, x2, x3)
        [features1, features2, features3] = model.encoder.predict({'input1': x1, 'input2': x2, 'input3': x3})
        # c1, c2, c3 = model.get_layers3()
        q_pred = (q1 + q2 + q3) / 3
        y_pred = np.argmax(q_pred, 1)
        print('V1:\t acc=%.4f, nmi=%.4f, v-measure=%.4f, ari=%.4f' % (Nmetrics.acc(y, y_pred1), Nmetrics.nmi(y, y_pred1),
                                                                Nmetrics.vmeasure(y, y_pred1),
                                                                Nmetrics.ari(y, y_pred1)))
        print('V2:\t acc=%.4f, nmi=%.4f, v-measure=%.4f, ari=%.4f' % (Nmetrics.acc(y, y_pred2), Nmetrics.nmi(y, y_pred2),
                                                                Nmetrics.vmeasure(y, y_pred2),
                                                                Nmetrics.ari(y, y_pred2)))
        print('V3:\t acc=%.4f, nmi=%.4f, v-measure=%.4f, ari=%.4f' % (Nmetrics.acc(y, y_pred3), Nmetrics.nmi(y, y_pred3),
                                                                Nmetrics.vmeasure(y, y_pred3),
                                                                Nmetrics.ari(y, y_pred3)))
        print('DEMCCT:\t acc=%.4f, nmi=%.4f, v-measure=%.4f, ari=%.4f' % (Nmetrics.acc(y, y_pred), Nmetrics.nmi(y, y_pred),
                                                                Nmetrics.vmeasure(y, y_pred), Nmetrics.ari(y, y_pred)))
        print('End testing:', '-' * 60)


if __name__ == "__main__":
    # setting the datasets
    # 'Nmnist_2_Rmnist-255-45'
    # 'Mnist-USPS-COMIC'
    # 'Sigle_Three_Fmnist_Test'
    # 'Sigle_Two_Fmnist_Test'
    # 'Sigle_Three_Mnist_Test'
    # 'Sigle_Two_Mnist_Test'
    TEST = True
    train_ae = False
    Coo = 1  # alternate
    data = 'Sigle_Two_Mnist_Test'
    Address = 'Test'   # this address is the process of fine-tune(ACC NMI ARI v-measure)
    C123q = 1  # kmeans-------1：k1 , 2：k2, 3：k3, 4: self_kmeans
    View = 1  # Coo target view First round of guidance

    # Determined training parameters
    epochs = 500
    Update_Coo = 200
    Update_samples = 2000
    Maxiter = 20000
    Batch = 256
    Idec = 1.0  # dec 0.0 , idec 1.0
    lrate = 0.001  # keras defult lr 0.001

    if data in['Sigle_Three_Fmnist_Test', 'Sigle_Three_Mnist_Test']:
        Multi_view = 3
    else:
        Multi_view = 2

    path = 'results/' + data
    if train_ae:
        load = None
    else:
        load = path + '/ae2_weights.h5'

    if TEST:
        load_test = path + '/model_final.h5'
    else:
        load_test = None
    addressACC = data + '/'

    import argparse
    parser = argparse.ArgumentParser(description='main')
    parser.add_argument('--dataset', default=data,
                        help="Dataset name to train on")
    parser.add_argument('--save_dir', default=path,
                        help="Dir to save the results")
    # Parameters for pretraining
    parser.add_argument('--pretrain', default=train_ae, type=str,
                        help="Pretrain autoencoder")
    parser.add_argument('--pretrain_dir', default=load, type=str,
                        help="Pretrained weights of the autoencoder")
    parser.add_argument('--pretrain_epochs', default=epochs, type=int,   # 500
                        help="Number of epochs for pretraining")
    parser.add_argument('--verbose', default=1, type=int,
                        help="Verbose for pretraining")
    # Parameters for clustering
    parser.add_argument('--testing', default=TEST, type=bool,
                        help="Testing the clustering performance with provided weights")
    parser.add_argument('--weights', default=load_test, type=str,
                        help="Model weights, used for testing")
    parser.add_argument('--lr', default=lrate, type=float,
                        help="learning rate during clustering")
    parser.add_argument('--batch_size', default=Batch, type=int,   # 256
                        help="Batch size")
    parser.add_argument('--maxiter', default=Maxiter, type=int,    # 2e4
                        help="Maximum number of iterations")
    parser.add_argument('--UpdateCoo', default=Update_Coo, type=int,   # 200  Alternate iteration
                        help="Number of iterations to update the target distribution")
    parser.add_argument('--tol', default=0.001, type=float,
                        help="Threshold of stopping training")
    parser.add_argument('--view_first', default=View, type=int,
                        help="first target view")
    parser.add_argument('--Coo', default=Coo, type=int,
                        help="is co-trainning")
    parser.add_argument('--K12q', default=C123q, type=int,
                        help="cluster centers")
    parser.add_argument('--ACC_addr', default=Address, type=str,
                        help="Address ACC NMI ARI Vmeasure")
    parser.add_argument('--Address', default=addressACC + Address, type=str,
                        help="Address ACC NMI ARI Vmeasure")
    parser.add_argument('--Idec', default=Idec, type=float,
                        help="is dec or Idec?")
    args = parser.parse_args()

    args.save_dir = 'results/' + args.dataset
    if args.pretrain:
        args.pretrain_dir = None
    else:
        args.pretrain_dir = args.save_dir + '/ae2_weights.h5'

    if args.testing:
        args.weights = args.save_dir + '/model_final.h5'
    else:
        args.weights = None

    if args.dataset in['Sigle_Three_Fmnist_Test', 'Sigle_Three_Mnist_Test']:
        Multi_view = 3
    else:
        Multi_view = 2

    addressACC = args.dataset + '/'
    args.Address = addressACC + args.ACC_addr

    print('+' * 30, ' Setting ', '+' * 30)
    print(args)
    print('+' * 75)
    # testing
    if args.testing:
        test(args, Multi_view)
    else:
        train(args, Multi_view)
