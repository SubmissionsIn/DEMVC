"""
Author:
    Jie Xu. 2020.1.1. in the UESTC
"""
import numpy as np
import matplotlib.pyplot as plt


def load_Sigle_Two_Mnist_test(dataset):
    FMx1 = np.load("./data/"+dataset+"/STMTmx1.npy")
    FMx2 = np.load("./data/"+dataset+"/STMTmx2.npy")
    y = np.load("./data/"+dataset+"/STMTmy.npy")
    ge = np.random.randint(0, len(FMx1), 1, dtype=int)
    image1 = np.reshape(FMx1[ge], (28, 28))
    image2 = np.reshape(FMx2[ge], (28, 28))
    print(y[ge][0])
    plt.figure('Mnist-v1')
    plt.imshow(image1)
    plt.show()
    plt.figure('Mnist-v2')
    plt.imshow(image2)
    plt.show()
    print('Sigle Two Mnist Test samples', FMx2.shape)
    return FMx1, FMx2, y


def load_Sigle_Two_Fmnist_test(dataset):
    FMx1 = np.load("./data/"+dataset+"/STFTmx1.npy")
    FMx2 = np.load("./data/"+dataset+"/STFTmx2.npy")
    y = np.load("./data/"+dataset+"/STFTmy.npy")
    ge = np.random.randint(0, len(FMx1), 1, dtype=int)
    image1 = np.reshape(FMx1[ge], (28, 28))
    image2 = np.reshape(FMx2[ge], (28, 28))
    print(y[ge][0])
    print(y.shape)
    plt.figure('Fmnist-v1')
    plt.imshow(image1)
    plt.show()
    plt.figure('Fmnist-v2')
    plt.imshow(image2)
    plt.show()
    print('Sigle Two Fmnist Test samples', FMx2.shape)
    return FMx1, FMx2, y


def load_Sigle_Three_Fmnist_test(dataset):
    FMx1 = np.load("./data/"+dataset+"/TFTx1.npy")
    FMx2 = np.load("./data/"+dataset+"/TFTx2.npy")
    FMx3 = np.load("./data/"+dataset+"/TFTx3.npy")
    y = np.load("./data/"+dataset+"/TFTy.npy")
    ge = np.random.randint(0, len(FMx1), 1, dtype=int)
    image1 = np.reshape(FMx1[ge], (28, 28))
    image2 = np.reshape(FMx2[ge], (28, 28))
    image3 = np.reshape(FMx3[ge], (28, 28))
    print(y[ge][0])
    print(y.shape)
    plt.figure('Fmnist-v1')
    plt.imshow(image1)
    plt.show()
    plt.figure('Fmnist-v2')
    plt.imshow(image2)
    plt.show()
    plt.figure('Fmnist-v3')
    plt.imshow(image3)
    plt.show()
    print('Three views of Fmnist-test samples', FMx1.shape)
    return FMx1, FMx2, FMx3, y


def load_Sigle_Three_Mnist_test(dataset):
    Mx1 = np.load("./data/"+dataset+"/TMTx1.npy")
    Mx2 = np.load("./data/"+dataset+"/TMTx2.npy")
    Mx3 = np.load("./data/"+dataset+"/TMTx3.npy")
    y = np.load("./data/"+dataset+"/TMTy.npy")
    ge = np.random.randint(0, len(Mx1), 1, dtype=int)
    image1 = np.reshape(Mx1[ge], (28, 28))
    image2 = np.reshape(Mx2[ge], (28, 28))
    image3 = np.reshape(Mx3[ge], (28, 28))
    print(y[ge][0])
    print(y.shape)
    plt.figure('Mnist-v1')
    plt.imshow(image1)
    plt.show()
    plt.figure('Mnist-v2')
    plt.imshow(image2)
    plt.show()
    plt.figure('Mnist-v3')
    plt.imshow(image3)
    plt.show()
    print('Three views of Mnist-test samples', Mx1.shape)
    return Mx1, Mx2, Mx3, y


def Get_Nmnist_Rmnist(dataset):
    Mxn = np.load("./data/"+dataset+"/NmRmXn.npy")
    Mxr = np.load("./data/"+dataset+"/NmRmXr.npy")
    y = np.load("./data/"+dataset+"/NmRmY.npy")
    ge = np.random.randint(0, len(Mxn), 1, dtype=int)
    image1 = np.reshape(Mxn[ge], (28, 28))
    image2 = np.reshape(Mxr[ge], (28, 28))
    print(y[ge][0])
    plt.figure('NoisyMnist')
    plt.imshow(image1)
    plt.show()
    plt.figure('RotatingMnist')
    plt.imshow(image2)
    plt.show()
    print('Multi-View:Noisy[0,255]-Rotating[-45,+45] Mnist samples', Mxn.shape)
    return Mxn, Mxr, y


def Get_MNIST_USPS_COMIC(dataset):
    x_shuffle_m = np.load("./data/"+dataset+"/MUCOMICx1.npy")
    x_shuffle_u = np.load("./data/"+dataset+"/MUCOMICx2.npy")
    y_shuffle = np.load("./data/"+dataset+"/MUCOMICy.npy")
    ge = np.random.randint(0, len(x_shuffle_m), 1, dtype=int)
    image1 = np.reshape(x_shuffle_m[ge], (28, 28))
    image2 = np.reshape(x_shuffle_u[ge], (28, 28))
    print(y_shuffle[ge][0])
    plt.figure('Mnist')
    plt.imshow(image1)
    plt.show()
    plt.figure('USPS')
    plt.imshow(image2)
    plt.show()
    print(x_shuffle_m.shape)
    print(x_shuffle_u.shape)
    print(y_shuffle.shape)
    print('5K Mnist-USPS samples', x_shuffle_m.shape)
    return x_shuffle_m, x_shuffle_u, y_shuffle


def load_data_conv(dataset):
    print("load:", dataset)
    if dataset == 'Sigle_Two_Mnist_Test':
        return load_Sigle_Two_Mnist_test(dataset)          # Mnist-10K
    elif dataset == 'Sigle_Three_Mnist_Test':
        return load_Sigle_Three_Mnist_test(dataset)        # TMnist-10K

    elif dataset == 'Sigle_Two_Fmnist_Test':
        return load_Sigle_Two_Fmnist_test(dataset)         # Fashion-10K
    elif dataset == 'Sigle_Three_Fmnist_Test':
        return load_Sigle_Three_Fmnist_test(dataset)       # TFashion-10K

    elif dataset == 'Nmnist_2_Rmnist-255-45':
        return Get_Nmnist_Rmnist(dataset)                  # Nm2Rm-70K
    elif dataset == 'Mnist-USPS-COMIC':                    # Mn2US-5K
        return Get_MNIST_USPS_COMIC(dataset)
    else:
        raise ValueError('Not defined for loading %s' % dataset)
